<template>

</template>

<script>
export default {
  name: "Patika"
}
</script>

<style scoped>

</style>