<template>

</template>

<script>
export default {
  name: "NewPatika"
}
</script>

<style scoped>

</style>