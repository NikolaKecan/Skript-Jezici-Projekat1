<template>

</template>

<script>
export default {
name: "SearchPatika"
}
</script>

<style scoped>

</style>