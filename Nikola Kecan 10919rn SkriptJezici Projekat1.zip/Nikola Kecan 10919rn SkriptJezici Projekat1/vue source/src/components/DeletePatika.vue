<template>

</template>


<script>
export default {
  name: "DeletePatika",
  props: {
    patike: Array
  },
  data() {
    return {
      idPatika: ''
    }
  },
  methods: {}


}
</script>




<style scoped>

</style>