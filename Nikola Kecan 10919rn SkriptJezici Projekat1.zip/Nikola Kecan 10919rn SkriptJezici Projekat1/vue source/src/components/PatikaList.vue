<template>
  <div>
    <b-table v-if="patike.length" sticky-header="500px" :items="patike"  head-variant="light"></b-table>
    <h1 v-else>Nema patika</h1>
  </div>
</template>

<script>
export default {
  name: "PatikaList",
  props: {
    patike: Array
  }
}
</script>

<style scoped>

</style>e>