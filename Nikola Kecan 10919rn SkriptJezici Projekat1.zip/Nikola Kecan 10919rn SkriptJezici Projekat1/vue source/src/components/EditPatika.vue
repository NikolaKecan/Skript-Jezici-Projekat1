<template>

</template>



<script>
export default {
  name: "EditPatika",
  props: {
    patike: Array
  },
  data() {
    return {
      idPatika:'',
      Ocena: '',
      Komentar: ''
    }
  },
  methods: {}




}
</script>

<style scoped>

</style>