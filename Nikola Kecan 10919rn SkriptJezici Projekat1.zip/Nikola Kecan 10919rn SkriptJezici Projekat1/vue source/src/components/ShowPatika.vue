<template>

</template>

<script>
export default {
  name: "ShowPatika"
}
</script>

<style scoped>

</style>