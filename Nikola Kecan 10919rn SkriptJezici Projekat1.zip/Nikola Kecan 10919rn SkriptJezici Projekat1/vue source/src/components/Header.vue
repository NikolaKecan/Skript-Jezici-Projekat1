<template>
  <div>
    <b-jumbotron header="Patike" :lead="'Recenzirano: ' + patike.length">
      <hr>
      <p>Unesi nove: </p>
      <b-container >
        <b-form>
          <b-row class="mt-2">
            <b-col sm="2" offset="0">
              <b-input v-model="Brend" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Brend"></b-input>
            </b-col>
            <b-col sm="2" offset="0">
              <b-input v-model="Model" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Model"></b-input>
            </b-col>
            <b-col sm="2" offset="0">
              <b-input v-model="Boja" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Boja"></b-input>
            </b-col>
            <b-col sm="2" offset="0">
              <b-input v-model="Ocena" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Ocena"></b-input>
            </b-col>
            <b-col sm="4" offset="0" >
              <b-form-textarea rows="5" v-model="Komentar" placeholder="Komentar..."></b-form-textarea>
            </b-col>
            <b-col sm="1">
              <b-button variant="primary" size="lg" @click="addNew">Ubaci</b-button>
            </b-col>
          </b-row>
        </b-form>
      </b-container>
    </b-jumbotron>

  </div>
</template>



<script>
export default {
  name: "Header",
  props: {
    patike: Array
  },
  data() {
    return {
      Brend: '',
      Model: '',
      Boja: '',
      Ocena: '',
      Komentar: ''
    }
  },
  methods: {
    addNew: function() {

      if (this.Brend === ''){
        alert("Ne moze tako!")
        return
      }

      fetch('http://localhost/api/patika', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({Brend: this.Brend, Model: this.Model, Boja: this.Boja, Ocena: this.Ocena, Komentar: this.Komentar})
      }).then((response) => {
        if (!response.ok)
          throw response;

        return response.json();
      }).then((jsonData) => {
        this.patike.push(jsonData);
        this.Brend = '';
        this.Model = '';
        this.Boja = '';
        this.Ocena = '';
        this.Komentar = '';
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    }
  }
}
</script>



<style scoped>

</style>