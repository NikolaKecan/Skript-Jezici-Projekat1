import Vue from 'vue'
import Vuex from 'vuex'







//################ Nisam koristio Vuex ##################











Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    patike : []   //PAZI OVDE KAKO SI NAZVAO
  },
  mutations: {
    set_patika: function (state, patike) {
      state.patike = patike;
    },

    add_patika: function (state, patika) { //PAZI OVDE SA IMENIMA DA LI SME PATIKA PTIKE U ODNOSU NA NODE stvari (ovde je patika nova jedna) (u node je patika cela tabela)
      state.patike.push(patika);
    },

    remove_patika: function (state, id) {   //DA LI OBDE TREBA idPatika?
      for (let m = 0; m < state.patike.length; m++) {
        if (state.patike[m].idPatika === id) { //DA LI OBDE TREBA idPatika?
          state.patike.splice(m, 1);
          break;
        }
      }
    },

    //DA LI OVDE TREBA DA UBACIM SVE ONE
    update_patika: function (state, payload) {
      for (let m = 0; m < state.patike.length; m++) {
        if (state.patike[m].idPatika === parseInt(payload.idPatika)) {  //DA LI OBDE TREBA idPatika?
          state.patike[m].Brend = payload.msg.Brend;
          state.patike[m].Model = payload.msg.Model;
          state.patike[m].Boja = payload.msg.Boja;
          state.patike[m].Ocena = payload.msg.Ocena;
          state.patike[m].Komentar = payload.msg.Komentar;
          break;
        }
      }
    }
  },
  actions: {

    //da dohvatimo sve patike sa servera i da ih sacuvamo u stanje.
    load_patika: function ({ commit }) {
      fetch('http://localhost/api/patika', { method: 'get' }).then((response) => {
        if (!response.ok)
          throw response;

        return response.json()
      }).then((jsonData) => {
        commit('set_patika', jsonData)
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    },

    delete_patika: function({ commit }, id) {
      fetch(`http://localhost/api/patika/${id}`, { method: 'delete' }).then((response) => {
        if (!response.ok)
          throw response;

        return response.json()
      }).then((jsonData) => {
        commit('remove_patika', jsonData.id)  //DA LI IDPATIKA?
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    },

    new_patika: function({ commit }, message) {
      fetch('http://localhost/api/patika', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json'
        },
        body: message
      }).then((response) => {
        if (!response.ok)
          throw response;

        return response.json();
      }).then((jsonData) => {
        commit('add_patika', jsonData);
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    },

    change_message: function({ commit }, payload) {
      fetch(`http://localhost/api/patika/${payload.id}`, {
        method: 'put',
        headers: {
          'Content-Type': 'application/json'
        },
        body: payload.msg
      }).then((response) => {
        if (!response.ok)
          throw response;

        return response.json();
      }).then((jsonData) => {
        commit('update_patika', {id: payload.id, msg:jsonData});
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    }

  }
})
