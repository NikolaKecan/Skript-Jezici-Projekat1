<template>
  <div id="app">
    <router-link to="/">
    <Header v-if="patike.length":patike="patike"/> <!-- Header dodaj patiku -->
    </router-link>

    <h2>Sve patike:</h2>
    <b-container><!-- tabela -->
      <b-row>
        <b-col cm="6" >
          <PatikaList  v-if="patike.length" :patike="patike"/>
        </b-col>
      </b-row>
    </b-container><!-- tabela/ -->


    <router-link to="/brisanje">
      <div> <!-- izbaci patiku -->
        <b-jumbotron :lead="'Izbaci patiku: '">
          <hr>
          <b-container >
            <b-form>
              <b-row class="mt-2">
                <b-col sm="2" offset="4">
                  <b-input v-model="idPatika" class="mb-2 mr-sm-2 mb-sm-0" placeholder="idPatika"></b-input>
                </b-col>
                <b-col sm="1">
                  <b-button variant="primary" size="lg" @click="deletePatika">Izbaci</b-button>
                </b-col>
              </b-row>
            </b-form>
          </b-container>
        </b-jumbotron>
      </div><!-- izbaci patiku/ -->
    </router-link>

    <router-link to="/editovanje">
    <div>
      <b-jumbotron :lead="'Izmeni recenziju patike: '">
        <hr>
        <b-container >
          <b-form>
            <b-row class="mt-2">
              <b-col sm="2" offset="0">
                <b-input v-model="idPatika2" class="mb-2 mr-sm-2 mb-sm-0" placeholder="idPatika"></b-input>
              </b-col>
              <b-col sm="2" offset="0">
                <b-input v-model="Ocena" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Ocena"></b-input>
              </b-col>
              <b-col sm="4" offset="0" >
                <b-form-textarea rows="5" v-model="Komentar" placeholder="Komentar..."></b-form-textarea>
              </b-col>
              <b-col sm="1">
                <b-button variant="primary" size="lg" @click="editPatika">Izmeni</b-button>
              </b-col>
            </b-row>
          </b-form>
        </b-container>
      </b-jumbotron>
    </div>
    </router-link>

    <!--  <SearchPatika v-if="patike.length":patike="patike"/> -->

    <div>
      <router-link to="/">
      <b-jumbotron :lead="'Pretrazi jednu patiku: '">
        <hr>
        <b-container >
          <b-form>
            <b-row class="mt-2">
              <b-col sm="2" offset="4">
                <b-input v-model="idPatika3" class="mb-2 mr-sm-2 mb-sm-0" placeholder="idPatika"></b-input>
              </b-col>
              <b-col sm="1">
                <b-button variant="primary" size="lg" @click="searchPatika">Pretraga</b-button>
              </b-col>
            </b-row>
          </b-form>
        </b-container>
      </b-jumbotron>
    </router-link>

      <b-container><!-- tabela za jednu patiku-->
        <b-row>
          <b-col cm="6" >
            <PatikaList  v-if="pronadjenaPatikaList.length" :patike="pronadjenaPatikaList"/>
          </b-col>
        </b-row>
      </b-container>
    </div>



     <router-view/>
   </div> <!-- zatvara app tag -->

</template>





<script>

import Header from './components/Header';
import PatikaList from "@/components/PatikaList";

export default {
  name: 'app',
  data() {
    return {

      patike: [],
      idPatika:'',
      idPatika2: '',
      idPatika3: '',
      pronadjenaPatikaList: []

    }
  },

  components: {
    Header,
    PatikaList,
  },

  mounted: function() {
    fetch('http://localhost/api/patika', { method: 'get' }).then((response) => {
      if (!response.ok)
        throw response;

      return response.json()
    }).then((jsonData) => {
      this.patike = jsonData;
    }).catch((error) => {
      if (typeof error.text === 'function')
        error.text().then((errorMessage) => {
          alert(errorMessage);
        });
      else
        alert(error);
    });
  },

  methods: {

    deletePatika: function () {
      var flag = false;
      for(let i = 0; i < this.patike.length; i++) {
        if(this.patike[i].idPatika == this.idPatika){
          flag = true;
          break;
        }
      }
      if(!flag){
        alert("Ne postoji patika sa tim id-om.");
        return;
      }
      fetch('http://localhost/api/patika/brisanje', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({idPatika: this.idPatika})
      }).then((response) => {
        if (!response.ok)
          throw response;
        return response.json();
      }).then((jsonData) => {
        this.patike = [];
        for(let i = 0; i < jsonData.length; i++) {
          this.patike.push(jsonData[i]);
        }
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    },



    editPatika: function() {
      var flag = false;
      for(let i = 0; i < this.patike.length; i++) {
        if(this.patike[i].idPatika == this.idPatika2){
          flag = true;
          break;
        }
      }
      if(!flag){
        alert("Ne postoji patika sa tim id-om.");
        return;
      }

      if(this.Ocena === ''){
        alert("Morate uneti ocenu.");
      }
      if(this.Komentar === ''){
        alert("Morate uneti komentar.");
      }

      fetch('http://localhost/api/patika/editovanje', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({idPatika: this.idPatika2, Ocena: this.Ocena, Komentar: this.Komentar})
      }).then((response) => {
        if (!response.ok)
          throw response;
        return response.json();
      }).then((jsonData) => {


        this.patike = [];
        for(let i = 0; i < jsonData.length; i++) {
          this.patike.push(jsonData[i]);
        }


      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    },



    searchPatika: function () {
      var flag = false;
      for(let i = 0; i < this.patike.length; i++) {
        if(this.patike[i].idPatika == this.idPatika3){
          flag = true;
          break;
        }
      }
      if(!flag){
        alert("Ne postoji patika sa tim id-om.");
        return;
      }
      fetch(`http://localhost/api/patika/${this.idPatika3}`, {
        method: 'get',
        headers: {
          'Content-Type': 'application/json',
        },

      }).then((response) => {
        if (!response.ok){
          throw response;
        }
        return response.json();
      }).then((jsonData) => {
        this.pronadjenaPatikaList = [];
        this.pronadjenaPatikaList.push(jsonData);
      }).catch((error) => {
        if (typeof error.text === 'function')
          error.text().then((errorMessage) => {
            alert(errorMessage);
          });
        else
          alert(error);
      });
    }




  }//kraj methods

}

</script>


<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
