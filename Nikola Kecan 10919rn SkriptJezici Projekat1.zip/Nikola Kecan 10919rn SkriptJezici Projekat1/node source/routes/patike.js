const express = require('express');
const Joi = require('joi');
const mysql = require('mysql');

const route = express.Router();

const pool = require('../database/db');
const sema = require('../database/schema');
const sema2 = require('../database/schema2');
const sema3 = require('../database/schema3');




route.use(express.json());








// PRIKAZ SVIH
route.get('/patika', (req, res) => {

    pool.query('select * from patika', (err, rows) => {
        if (err)
            res.status(500).send(err.sqlMessage);
        else
            res.send(rows);
    });
});





//KREIRANJE
route.post('/patika', (req, res) => {

    let { error } = sema.validate(req.body);


    if (error)
        res.status(400).send(error.details[0].message);
    else {
        let query = "insert into patika (Brend, Model, Boja, Ocena, Komentar) values (?, ?, ?, ?, ?)";
        let formated = mysql.format(query, [req.body.Brend, req.body.Model, req.body.Boja, req.body.Ocena, req.body.Komentar]);

        pool.query(formated, (err, response) => {
            if (err)
                res.status(500).send(err.sqlMessage);
            else {
                query = 'select * from patika where idPatika=?';
                formated = mysql.format(query, [response.insertId]);

                pool.query(formated, (err, rows) => {
                    if (err)
                        res.status(500).send(err.sqlMessage);
                    else
                        res.send(rows[0]);
                });
            }
        });
    }
});







//SEARCH
route.get('/patika/:idPatika', (req, res) => {

    let { error } = sema2.validate(req.params);

    if(error)
        res.status(404).send(error.details);
    else{
        let query = 'select * from patika where idPatika=?';
        let formated = mysql.format(query, [req.params.idPatika]);

        pool.query(formated, (err, rows) => {
            if (err)
                res.status(500).send(err.sqlMessage);
            else{
                res.send(rows);
            }

        });
    }

});





//EDIT
route.post('/patika/editovanje', (req, res) => {

    let { error } = sema3.validate(req.body);

    if (error)
        res.status(400).send(error.details[0].message);
    else {
        let query = "update patika set Ocena=?, Komentar=? where idPatika=?";
        let formated = mysql.format(query, [req.body.Ocena, req.body.Komentar, req.body.idPatika]);

        pool.query(formated, (err, response) => {
            if (err)
                res.status(500).send(err.sqlMessage);
            else {
                query = 'select * from patika';
                formated = mysql.format(query, [req.params.idPatika]);

                pool.query(formated, (err, rows) => {
                    if (err)
                        res.status(500).send(err.sqlMessage);
                    else
                        res.send(rows);
                });
            }
        });
    }

});









// DELETE
route.post('/patika/brisanje', (req, res) => {

    let { error } = sema2.validate(req.body);

    if (error)
        res.status(400).send(error.details[0].message);
    else {

        let query = 'delete from patika where idPatika=?';
        let formated = mysql.format(query, [req.body.idPatika]);

        pool.query(formated, (err, response) => {
            if (err)
                res.status(500).send(err.sqlMessage);
            else {

                let query = 'select * from patika';
                pool.query(query, (err, rows) => {
                    if (err)
                        res.status(500).send(err.sqlMessage);
                    else
                        res.send(rows);
                });
            }
        });
    }
});






module.exports = route;