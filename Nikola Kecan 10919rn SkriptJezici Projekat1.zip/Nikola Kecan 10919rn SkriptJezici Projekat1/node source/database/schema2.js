const Joi = require('joi');


const sema2 = Joi.object().keys({

    idPatika: Joi.number().required(),


});




module.exports = sema2;