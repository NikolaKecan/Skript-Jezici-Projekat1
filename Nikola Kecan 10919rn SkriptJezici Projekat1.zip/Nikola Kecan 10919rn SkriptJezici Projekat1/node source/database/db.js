const mysql = require('mysql');


const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'localhost',
    user: 'root',
    password: '*****', //sakrio sifru
    database: 'skriptjezici',
    port: '3306'
});


module.exports = pool

