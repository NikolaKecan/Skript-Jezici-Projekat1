
const Joi = require('joi');


const sema3 = Joi.object().keys({

    idPatika: Joi.number().required(),
    Ocena: Joi.number().integer().min(1).max(5).required(),
    Komentar: Joi.string().trim().min(1).max(195).required()


});




module.exports = sema3;