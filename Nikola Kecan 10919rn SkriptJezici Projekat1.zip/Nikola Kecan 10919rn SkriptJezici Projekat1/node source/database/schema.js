const Joi = require('joi');


const sema = Joi.object().keys({


    Brend: Joi.string().trim().min(1).max(25).required(),
    Model: Joi.string().trim().min(1).max(25).required(),
    Boja: Joi.string().trim().min(1).max(25).required(),
    Ocena: Joi.number().integer().min(1).max(5).required(),
    Komentar: Joi.string().trim().min(1).max(195).required()


});




module.exports = sema;


